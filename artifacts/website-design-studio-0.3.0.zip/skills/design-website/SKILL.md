---
name: design-website
description: Design and refine website interfaces, compare visual directions, build clickable UI prototypes, or review visual quality and responsive behavior. Use with or without Figma references; adapts to existing project components and design systems.
---

# Website Design Studio

Turn the user's website intent into an inspectable visual result. Match their language. Support landing pages, content sites, commerce, dashboards and internal tools; do not assume every site is an admin dashboard.

## Choose the scope

- For ideas or exploration, show distinct visual directions and their tradeoffs. Do not install dependencies or change an application when only advice was requested.
- For a preview request, produce a viewable artifact using available local or host preview capabilities. Describe an image as a visual mockup, not a clickable prototype.
- For implementation, inspect repository instructions, framework versions, existing components and tokens before editing. Honor the existing stack; a new design does not justify a framework migration.
- For an existing-page review, prioritize observable usability and visual defects. Read [review.md](references/review.md).
- With Figma input, read [figma.md](references/figma.md) before interpreting or fetching the design.
- For multilingual interfaces, language switching or RTL, read [internationalization.md](references/internationalization.md). Preserve the project's locale contract.
- For multiple themes, comfortable reading or color-vision accessibility, read [themes-accessibility.md](references/themes-accessibility.md). Color-independent meaning is a baseline in every theme.
- For responsive implementation or mobile review, read [mobile.md](references/mobile.md).
- For inspiration, competitor research, current examples or user-provided reference websites, read [website-research.md](references/website-research.md). Research is optional when the direction is already clear.
- For audio/video with synchronized transcripts, click-to-seek or segment loops, read [media-transcripts.md](references/media-transcripts.md).
- For Markdown reading pages, read [markdown-reader.md](references/markdown-reader.md).
- For PDF viewing pages, read [pdf-reader.md](references/pdf-reader.md).
- For field-filtered lists and data tables, read [filtered-lists.md](references/filtered-lists.md).
- For video browsing, detail and playlist pages, read [video-sites.md](references/video-sites.md); combine it with the transcript reference only when needed.

Infer the audience, primary task, content, brand constraints and delivery target from context. Ask only for missing information that materially changes the result, and continue independent work. If told to explore first, avoid treating a proposed direction as a selection. For implementation without a selected style, choose a reasonable direction and state the assumption.

## Design and preview

Use [design-system.md](references/design-system.md) for tokens, composition and responsive decisions. If direction is open, normally offer two or three meaningfully different compositions using the same content and primary task. Vary information hierarchy, typography, density or navigation as appropriate, not just accent color. A narrow edit rarely needs alternatives.

Make the initial viewport communicate purpose and a primary action. Use plausible, clearly fictional sample content. Include long names and realistic data density where useful. Carry the selected direction into supporting states and mobile layouts. Keep changes to one component local unless a shared token is responsible.

For a clickable prototype, implement the main journey with meaningful feedback: navigation, search/filter, modal open/close, form validation or another task-relevant interaction. Label mocked persistence or integrations. Do not attach destructive prototype actions to live data. Reuse accessible primitives already in the project.

Persist established design decisions in the project's existing design documentation or a small project-local design note when useful: selected direction, semantic tokens, reused components, layout rules and open decisions. This is the continuity mechanism; do not claim memory outside saved artifacts.

Capture supported locales, themes and target devices when relevant. A design plugin having these workflows does not mean every website needs every locale or theme. Keep language, appearance and accessibility preferences independent. Do not turn a small UI edit into a localization or theme-system migration.

For specialized pages, record a small behavior contract before implementation: supported inputs, authoritative state, user actions, transitions, error/empty states, persistence and acceptance scenarios. Reuse established project contracts, components, dependencies and saved decisions. Do not choose a different library or interaction model on each request without a concrete reason. Resolve meaningful ambiguities from context, stating reversible assumptions; ask when the choice affects the intended workflow. Preserve creative freedom in unspecified presentation, not in specified behavior. Skills guide decisions; they do not make generation deterministic or replace executable verification.

## Documentation and tools

Use available Context7 tools for library-specific implementation questions: resolve the library first, then query focused documentation matching installed versions. Record relevant source links and distinguish documentation evidence from recommendations. Do not send project secrets or proprietary source as search queries. If unavailable, disclose that and use official docs or local package documentation; do not invent a successful lookup.

Figma and browser tools are optional host capabilities, not tools supplied by this plugin. Discover what is actually callable. Without a browser, deliver a runnable preview and report visual checks as pending. Without Figma access, work from supplied screenshots/exports or proceed with an original design when authorized. No new account or service is required for the core workflow.

## Verify and hand off

Read [review.md](references/review.md) and perform checks proportionate to the task. For implementation, use the project's relevant build/type checks and inspect desktop and narrow-screen behavior when tools permit. Fix observed failures, then report what was verified and any limitations. A successful build alone is not evidence of visual fidelity.

For multi-locale or multi-theme work, report a compact verification matrix with locale, theme/accessibility preference, viewport/input, journey/state, result and evidence. Cover every supported locale and theme at least once, plus stress intersections such as long translated text on mobile and error states in dark mode. Use risk-based combinations rather than claiming all permutations passed. Mark simulation, desktop emulation, physical-device checks and untested combinations distinctly.

Provide the artifact/preview location, design rationale, important interactions and verification status. Keep delivery concise. Do not publish a site or mutate Figma merely because a local design was requested.


