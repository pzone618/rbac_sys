# Verification — 2026-10-15

- Python 3.12.4, Windows; Node 22.17.1.
- 10 Python tests passed: MCP initialization/tool discovery/doctor/catalog calls over actual stdio; offline network prohibition; invalid inputs; cache behavior; Azure SSML escaping; ElevenLabs and Speech API request contracts; invalid audio rejection; local-only sherpa paths; sanitized unexpected errors.
- 4 Node tests passed: Unicode/multilingual splitting, SSR failure, local-only voice filtering, cancellation, rapid reading replacement and completion.
- Skill frontmatter validator passed.
- Actual Windows SAPI enumeration returned David, Zira, Haruka, Huihui and Tracy.
- Actual local synthesis: Huihui Chinese/date/amount/English sample generated a 581728-byte, 22050 Hz WAV lasting 13.190 seconds. Zira English sample generated a 301624-byte, 22050 Hz WAV lasting 6.839 seconds. Repeating the Huihui request hit cache with identical file SHA-256. Samples remain in workspace `.local/tts-studio-verification/`, outside the plugin archive.
- SAPI enumeration/synthesis needed execution outside this session's sandbox; the sandbox restricted the speech service. This is an execution environment limitation, not evidence that no local voices are installed.
- No subjective listening evaluation was performed. No target-browser UI, mobile or disconnected-device test was performed; browser tests use a mock speech engine.
- sherpa-onnx and model weights are not installed in this environment. Constructor/API shape was checked against Context7 official-documentation excerpts; real neural synthesis remains unverified.
- Cloud environment credentials were absent. Cloud HTTP payloads were tested using simulated responses; no real cloud synthesis, billing, latency or account permissions were exercised.
- No global environment, project MCP configuration, or model download was changed. Account saving and target-host installation/tool activation are separate steps.

## Sources

Context7 library search plus context retrieval was used for sherpa, Kokoro, Piper, Qwen3-TTS, CosyVoice, F5-TTS, Azure Speech, ElevenLabs and Google Cloud TTS. Raw results are in `research/`. Official web sources supplemented current Piper upstream, hosted Chinese services, Polly, OpenAI, Gemini and specialist models. The catalogue records canonical links; false matches and failed Context7 queries are explicitly noted in the engine guide.
