# 本地运行与网站复用

插件根目录以 `<plugin>` 表示。需要 Python 3.10+，MCP 服务器自身只使用标准库。Windows 适配器使用 Windows PowerShell 的 System.Speech。没有自动安装模型或上传文本。

```powershell
python <plugin>/server/tts_server.py doctor
python <plugin>/server/tts_server.py catalog
python <plugin>/server/tts_server.py voices --provider windows
python <plugin>/server/tts_server.py synthesize --provider windows --voice "Microsoft Huihui Desktop" --text "你好，欢迎使用语音朗读。"
```

输出默认在当前工作目录的 `tts-output/`。可设置 `TTS_OUTPUT_DIR` 到自己的资源目录。文件名按请求与引擎配置哈希生成，重复请求命中缓存；不会把文本写入额外的元数据文件。音频本身可能包含私人内容，按项目资源处理。模型/音色内容更新后修改 `TTS_CACHE_REVISION` 以刷新缓存；插件不监测模型文件内容变化。

所有适配器返回路径、格式、字节数、音频哈希、缓存命中状态；WAV 另返回采样率和时长。MP3 不猜测时长。Windows 语速映射是近似值，各引擎相同 speed 不保证相同韵律。

## sherpa-onnx

在运行 MCP 的 Python 环境安装 `sherpa-onnx`；从官方模型目录选择并下载模型，保持每个模型包的 tokens/lexicon/phonemizer 一致。配置 JSON 只能引用已经存在的绝对本地路径。当前适配器转换 VITS、Matcha、Kokoro 三类配置，不覆盖 sherpa 的所有模型。

```json
{
  "model": {
    "vits": {
      "model": "C:/models/selected/model.onnx",
      "tokens": "C:/models/selected/tokens.txt",
      "lexicon": "C:/models/selected/lexicon.txt"
    },
    "num_threads": 2,
    "provider": "cpu",
    "debug": false
  },
  "max_num_sentences": 1
}
```

这是配置形状示例，路径和字段必须按选中的实际模型修改，不能直接运行。Piper 系 VITS 常需要 `data_dir`；中文模型可能需要 `rule_fsts`。Kokoro 使用 `kokoro` 块及其 `model/voices/tokens/data_dir/lexicon`；Matcha 使用 `matcha` 块及其 `acoustic_model/vocoder/tokens/lexicon`。以 [官方示例](https://k2-fsa.github.io/sherpa/onnx/tts/index.html)为准。

设置 `TTS_SHERPA_CONFIG` 为配置文件的绝对路径。`voice` 对此适配器表示数字 speaker ID，默认 `0`。加载模型的日志必须写 stderr；本插件将 sherpa 的 Python stdout 重定向至 stderr，原生运行库如向 stdout 写日志则需要在宿主配置中禁用相应日志。每次请求加载模型；本版不提供 GPU 常驻推理或实时流。

## 云端

| 适配器 | 环境变量 | 当前格式 |
|---|---|---|
| azure | `AZURE_SPEECH_KEY`、`AZURE_SPEECH_REGION`；可选 `AZURE_SPEECH_VOICE`、`AZURE_SPEECH_LANGUAGE` | WAV、MP3 |
| elevenlabs | `ELEVENLABS_API_KEY`、`ELEVENLABS_MODEL_ID`、`ELEVENLABS_VOICE_ID` | MP3，speed=1 |
| speech-api | `TTS_SPEECH_URL`、`TTS_SPEECH_API_KEY`、`TTS_SPEECH_MODEL`、`TTS_SPEECH_VOICE` | WAV、MP3，取决于服务支持 |

```powershell
python <plugin>/server/tts_server.py synthesize --provider azure --text "欢迎光临。" --format mp3 --allow-online
```

`speech-api` 接受实现 `model/input/voice/response_format/speed` 请求体、Bearer 认证、二进制音频响应的 HTTPS 服务。OpenAI 的完整 endpoint 为 `https://api.openai.com/v1/audio/speech`，模型与音色从当前官方文档/账号选择。其他所谓兼容接口需单独核对，不能假设百炼、豆包、MiniMax 或 Gemini 都可直接套用。不接受 HTTP 本机服务；本地服务适配应作为单独 provider 实现，不将其误标为离线。

不要在聊天、前端代码或插件包中保存密钥。环境变量由启动 MCP 的进程继承；本插件不自动加载 `.env`。在线请求显式开启，错误后不自动重试，不将文本转发给其他供应商。Azure SSML 会转义文本，输入中的标签按普通文字处理。ElevenLabs voice listing 当前只取第一页（最多100项），不是整个账号的完整音色列表。

## 浏览器示例

在 `skills/website-tts/assets` 目录启动静态文件服务，然后打开 `reader-example.html`。ES module 应通过 HTTP 提供。`browser-tts.mjs` 可以复制进已有 React/Vue/原生 JS 项目，客户端初始化，卸载时 `dispose()`；一个页面保留一个实例，因为 Web Speech 队列是全局的。

浏览器模块是客户端朗读，不调用 MCP。生成好的音频复制到网站静态资源目录并用 `<audio controls src="...">` 播放。要做动态云端合成，在网站自己的后端使用适配器逻辑并补齐项目已有的认证、限流和资源生命周期；不要把此 stdio MCP 服务器直接公开上网。
