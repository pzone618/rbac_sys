# TTS Studio 0.1.0

网站指定文本朗读与在线/离线音频生成插件。包含 `website-tts` 技能、浏览器朗读模块、Python MCP 服务器，以及 15 项离线 / 13 项在线方案的选型清单。使用 Context7 查询并补充官方来源核对，日期为 2026-10-15。

- [选型清单与建议](skills/website-tts/references/engines.md)
- [运行、凭据、模型和网站集成](skills/website-tts/references/runtime.md)
- [浏览器朗读示例](skills/website-tts/assets/reader-example.html)
- [机器可读清单](catalog.json)

已实现 Windows SAPI、sherpa VITS/Matcha/Kokoro、Azure Speech、ElevenLabs 和可配置 Speech API 适配器。神经模型和云端密钥不随包提供。MCP 提供 `tts_doctor`、`tts_catalog`、`tts_voices`、`tts_synthesize` 四个工具。默认仅允许离线合成；云端显式开启。

Portable `mcp.json` 使用 `${PLUGIN_ROOT}`；本地 Codex 兼容配置使用 `${CLAUDE_PLUGIN_ROOT}`。宿主需要支持本地 Python stdio 进程。保存到账户不等于安装或启动本机服务器；网页/手机宿主不能直接执行本机进程。工具未加载时，技能可按运行文档调用绝对路径 CLI。

## 验证

```powershell
python -m unittest discover -s <plugin>/tests -p "test_*.py"
node --test <plugin>/tests/browser.test.mjs
python <plugin>/server/tts_server.py doctor
```

离线音色、真实云端请求、浏览器设备断网与主观试听各自需要对应环境；模拟接口测试不代表已通过供应商联网测试。详见交付验证记录。此版本不提供实时流式 MCP、逐词时间戳、克隆工具、自动模型下载或自动 MP3 转码。
